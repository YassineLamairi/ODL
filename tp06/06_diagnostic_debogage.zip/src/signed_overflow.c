#include <stdio.h>

int main(void) {
    int width = 50000;
    int height = 50000;
    int area = width * height;

    printf("Aire : %d\n", area);
    return 0;
}
